PRAGMA journal_mode = WAL;
CREATE TABLE users (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,password TEXT NOT NULL);
INSERT INTO users (username, password) VALUES ('admin', 'Sha256:10000:Hq+L9F8x1zQ3gP8FZL/cug==:ra4Ho6znzsUJnGVIuezMCA==');
CREATE TABLE servers_compute ( id integer NOT NULL PRIMARY KEY,
                               name varchar(20) NOT NULL,
                               hostname varchar(20) NOT NULL,
                               login varchar(20), 
                               password varchar(14),type integer NOT NULL);
INSERT INTO servers_compute (id,name,hostname,type) 
                     VALUES (1,'Fleet Compute','localhost',4);
CREATE TABLE create_flavor ( id integer NOT NULL PRIMARY KEY, 
                             label varchar(12) NOT NULL, 
                             memory integer NOT NULL, 
                             vcpu integer NOT NULL, 
                             disk integer NOT NULL);
INSERT INTO create_flavor (label, memory, vcpu, disk) values ('micro', 512, 1, 20);
INSERT INTO create_flavor (label, memory, vcpu, disk) values ('mini', 1024, 2, 30);
INSERT INTO create_flavor (label, memory, vcpu, disk) values ('small', 2048, 2, 40);
INSERT INTO create_flavor (label, memory, vcpu, disk) values ('medium', 4096, 2, 60);
INSERT INTO create_flavor (label, memory, vcpu, disk) values ('large', 8192, 4, 80);
INSERT INTO create_flavor (label, memory, vcpu, disk) values ('xlarge', 16348, 8, 160);
